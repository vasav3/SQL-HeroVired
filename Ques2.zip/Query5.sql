5. SQL> alter table Football_venue
   2  rename column venue_name to Location;



SQL> alter table Football_venue
  2  rename column capacity to volume;

SQL>select * from Football_venue;

SQL> select Location,volume from Football_venue;