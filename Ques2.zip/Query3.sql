3.SQL> insert into Football_venue values
  2  (
  3  1201,
  4  'paris',
  5  38756,
  6  5000
  7  );

1 row created.



SQL> insert into Football_venue values
  2  (
  3  2122,
  4  'russia',
  5  12347,
  6  7500
  7  );

1 row created.

SQL> insert into Football_venue values
  2  (
  3  20003,
  4  'france',
  5  10004,
  6  60007
);

1 row created.

SQL> insert into Football_venue values
  2  (
  3  20004,
  4  'Amsterdam',
  5  10008,
  6  38048
);

1 row created.

SQL> insert into Football_venue values
  2  (
  3  1218,
  4  'Brazil',
  5  78000,
  6  78063
);

1 row created.

SQL> insert into Football_venue values
  2  (
  3  1244,
  4  'Quatar',
  5  19876,
  6  2000
);

1 row created.

SQL> insert into Football_venue values
  2  (
  3  1202,
  4  'Nigeria',
  5  11000,
  6  3900
);

1 row created.

SQL> insert into Football_venue values
  2  (
  3  1210,
  4  'South Korea',
  5  11987,
  6  7654
);

1 row created.

SQL> insert into Football_venue values
  2  (
  3  1212,
  4  'Russia',
  5  12498,
  6  5000
);

1 row created.

SQL> insert into Football_venue values
  2  (
  3  1211,
  4  'Norway',
  5  12345,
  6  4000
);

1 row created.
