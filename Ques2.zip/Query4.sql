4. SQL> select count(*) from Football_venue;
