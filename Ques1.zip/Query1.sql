1)

create database empolyee;
use empolyee;