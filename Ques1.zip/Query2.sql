2)

create table employee_details
  2  (
  3  emp_id number(4),
  4  emp_name varchar2(20),
  5  job_name varchar2(20),
  6  manager_id number(7),
  7  hire_date date,
  8  salary number(7),
  9  dep_id number(5)
 10  );
