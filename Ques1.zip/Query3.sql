3)

SQL> insert into employee_details values(&a,&b,&c,&d,&e,&f,&g);
Enter value for a: 1201
Enter value for b: 'hani'
Enter value for c: 'manager'
Enter value for d: 1
Enter value for e: '10-jan-01'
Enter value for f: 80000
Enter value for g: 1
------------------------------------------------------------------------------------------------------------------------

SQL> insert into employee_details values(&a,&b,&c,&d,&e,&f,&g);
Enter value for a: 1202
Enter value for b: 'kavya'
Enter value for c: 'developer'
Enter value for d: 2
Enter value for e: '24-jan-20'
Enter value for f: 60000
Enter value for g: 2
--------------------------------------------------------------------------------------------------------------------------


SQL> insert into employee_details values(&a,&b,&c,&d,&e,&f,&g);
Enter value for a: 1212
Enter value for b: 'gulshan'
Enter value for c: 'developer'
Enter value for d: 3
Enter value for e: '18-mar-02'
Enter value for f: 65000
Enter value for g: 3
----------------------------------------------------------------------------------------------------------------------
SQL> insert into employee_details values(&a,&b,&c,&d,&e,&f,&g);
Enter value for a: 1211
Enter value for b: 'dighvijay'
Enter value for c: 'programmer'
Enter value for d: 4
Enter value for e: '23-dec-02'
Enter value for f: 75000
Enter value for g: 4
--------------------------------------------------------------------------------------------------------------------
SQL> insert into employee_details values(&a,&b,&c,&d,&e,&f,&g);
Enter value for a: 1218
Enter value for b: 'vinnu'
Enter value for c: 'anaylst'
Enter value for d: 5
Enter value for e: '03-mar-02'
Enter value for f: 45000
Enter value for g: 5
--------------------------------------------------------------------------------------------------------------------
SQL> insert into employee_details values(&a,&b,&c,&d,&e,&f,&g);
Enter value for a: 1244
Enter value for b: 'Anitha'
Enter value for c: 'analyst'
Enter value for d: 6
Enter value for e: '14-feb-02'
Enter value for f: 75000
Enter value for g: 6
---------------------------------------------------------------------------------------------------------------------
SQL> insert into employee_details values(&a,&b,&c,&d,&e,&f,&g);
Enter value for a: 1210
Enter value for b: 'Abhi'
Enter value for c: 'analyst'
Enter value for d: 7
Enter value for e: '20-aug-02'
Enter value for f: 65000
Enter value for g: 7
-------------------------------------------------------------------------------------------------------------------------
SQL> insert into employee_details values(&a,&b,&c,&d,&e,&f,&g);
Enter value for a: 1203
Enter value for b: 'vyshu'
Enter value for c: 'analyst'
Enter value for d: 8
Enter value for e: '25-nov-02'
Enter value for f: 85000
Enter value for g: 8
--------------------------------------------------------------------------------------------------------------------------
SQL> insert into employee_details values(&a,&b,&c,&d,&e,&f,&g);
Enter value for a: 1265
Enter value for b: 'Surya'
Enter value for c: 'Full stack developer'
Enter value for d: 9
Enter value for e: '09-oct-01'
Enter value for f: 30000
Enter value for g: 9
--------------------------------------------------------------------------------------------------------------------
SQL> insert into employee_details values(&a,&b,&c,&d,&e,&f,&g);
Enter value for a: 1227
Enter value for b: 'Arjun'
Enter value for c: 'web developer'
Enter value for d: 10
Enter value for e: '27-sep-02'
Enter value for f: 95000
Enter value for g: 10